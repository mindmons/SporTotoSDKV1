//
//  SporTotoSDKV1.h
//  SporTotoSDKV1
//
//  Created by argedor on 15.09.2025.
//

#import <Foundation/Foundation.h>

//! Project version number for SporTotoSDKV1.
FOUNDATION_EXPORT double SporTotoSDKV1VersionNumber;

//! Project version string for SporTotoSDKV1.
FOUNDATION_EXPORT const unsigned char SporTotoSDKV1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SporTotoSDKV1/PublicHeader.h>


